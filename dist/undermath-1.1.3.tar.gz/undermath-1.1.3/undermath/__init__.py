"""
    Este es un paquete básico con módulos aritméticos y estadísticos
    para la tarea del Bootcamp de Python Avanzado de Código Facilito
"""
