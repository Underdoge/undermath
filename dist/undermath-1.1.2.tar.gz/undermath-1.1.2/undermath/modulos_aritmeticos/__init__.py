""" Este módulo contiene un submódulo llamado operaciones_basicas.py que
    contiene funciones para sumar, restar, multiplicar y dividir.
"""
