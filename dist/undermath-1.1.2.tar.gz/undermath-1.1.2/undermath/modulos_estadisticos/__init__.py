""" Este módulo contiene un submódulo llamado funciones_estadisticas.py que
    contiene funciones para optener la media, mediana, moda, y desviación
    estándar muestral y poblacional.
"""
